# com.compucorp.tasks
Create a new CiviCRM extension that creates a new page in CiviCRM that displays a list of the current memberships.  Create a simple filter on the page to filter by membership start date from and to.
##AngularJS extension
The civicrm extension creates a page using generate:angular-module. <br />

##Installation
Install the civicrm extension using the CiviCRM extension uploader. Enable the application. <br />
Or you can extract all files inside [drupal_dir]/sites/all/modules/civicrm/ext/com.compucorp.tasks <br />
A menu should show "Compucorp Tasks" on the navigation. <br />
OR Navigate to civicrm/a/#/membership
