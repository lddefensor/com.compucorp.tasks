<?php
// This file declares an Angular module which can be autoloaded
// in CiviCRM. See also:
// http://wiki.civicrm.org/confluence/display/CRMDOC/hook_civicrm_angularModules

return array (
  'js' => 
  array (
    0 => 'ang/weather.js',
    1 => 'ang/weather/*.js',
    2 => 'ang/weather/*/*.js'
  ),
  'css' => 
  array (  
    0 => 'ang/weather/css/*.css',  
    1 => 'ang/weather/weather-icons/css/weather-icons.css', 
  ),
  'partials' => 
  array (
    0 => 'ang/weather',
  ),
  'settings' => 
  array (
  ),
);